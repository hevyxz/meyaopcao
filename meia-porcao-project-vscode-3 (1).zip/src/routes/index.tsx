import { createFileRoute } from "@tanstack/react-router";
import sushiImg from "@/assets/meia-sushi.jpg";
import lancheImg from "@/assets/meia-lanche.jpg";
import lojaImg from "@/assets/loja-meia-porcao.jpg";
import { Conta, brl, useComanda, type Item } from "@/components/comanda";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Meia Porção — Meias de Sushi e Hambúrguer" },
      {
        name: "description",
        content:
          "Cardápio de meias divertidas: kit sushi e kit hambúrguer em algodão premium. Monte sua comanda, feche a conta e receba em casa.",
      },
      { property: "og:title", content: "Meia Porção — Meias de Sushi e Hambúrguer" },
      {
        property: "og:description",
        content: "Meias autorais de sushi e lanche. Monte sua comanda e feche a conta.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const ITENS: Item[] = [
  {
    id: "sushi",
    nome: "Kit Sushi — 3 pares",
    chamada: "Entrada",
    descricao:
      "Nigiri de salmão, uramaki e hossomaki impressos em algodão penteado. Servido fresquinho, direto da esteira.",
    preco: 79.9,
    img: sushiImg,
    tags: ["Algodão penteado", "3 pares", "34 ao 43"],
  },
  {
    id: "lanche",
    nome: "Kit Lanche — 2 pares",
    chamada: "Prato principal",
    descricao:
      "Pão brioche com gergelim, cheddar derretido, alface e blend 180g. Ponto da malha: ao ponto para o mal passado.",
    preco: 59.9,
    img: lancheImg,
    tags: ["Cano médio", "2 pares", "34 ao 43"],
  },
];

function Index() {
  const { linhas, add, remove } = useComanda();

  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-4">
          <span className="text-2xl tracking-widest" style={{ fontFamily: "var(--font-display)" }}>
            MEIA<span className="text-gradient-gold">PORÇÃO</span>
          </span>
          <a
            href="#cardapio"
            className="rounded-full border border-gold/40 px-4 py-2 text-xs uppercase tracking-[0.2em] text-gold"
          >
            Ver cardápio
          </a>
        </div>
      </header>

      <section className="relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
        <div className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 sm:py-24 lg:grid-cols-2">
          <div>
            <p className="mb-4 text-xs uppercase tracking-[0.4em] text-gold">
              Casa de meias · desde 2019
            </p>
            <h1 className="text-5xl leading-[0.95] sm:text-7xl">
              O melhor rodízio
              <br />
              <span className="text-gradient-gold">que cabe no seu pé.</span>
            </h1>
            <p className="mt-6 max-w-md text-muted-foreground">
              Meias autorais de sushi e hambúrguer. Você escolhe no cardápio, monta a comanda e
              fecha a conta — a gente entrega quentinho na sua porta.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#cardapio"
                className="rounded-full bg-primary px-7 py-4 text-sm font-bold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-[1.03]"
                style={{ boxShadow: "var(--shadow-lux)" }}
              >
                Pedir agora
              </a>
            </div>
          </div>
          <div className="relative">
            <img
              src={sushiImg}
              alt="Kit de meias estampadas com sushi"
              width={1024}
              height={1024}
              className="w-full rounded-3xl object-cover"
              style={{ boxShadow: "var(--shadow-lux)" }}
            />
            <img
              src={lancheImg}
              alt="Meias estampadas como hambúrguer"
              loading="lazy"
              width={1024}
              height={1024}
              className="absolute -bottom-8 -left-6 w-1/2 rounded-2xl border border-gold/30 object-cover sm:-left-10"
              style={{ boxShadow: "var(--shadow-card)" }}
            />
          </div>
        </div>
      </section>

      <section id="cardapio" className="mx-auto max-w-6xl px-5 py-20">
        <img
          src={lojaImg}
          alt="Fachada criativa da loja Meia Porção com meias de sushi e hambúrguer na vitrine"
          loading="lazy"
          width={1280}
          height={896}
          className="mb-12 w-full rounded-3xl object-cover"
          style={{ boxShadow: "var(--shadow-lux)" }}
        />
        <div className="mb-10 text-center">
          <p className="text-xs uppercase tracking-[0.4em] text-gold">Cardápio da casa</p>
          <h2 className="mt-3 text-4xl sm:text-5xl">Escolha sua porção</h2>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1.4fr_1fr]">
          <div className="space-y-6">
            {ITENS.map((item) => (
              <article
                key={item.id}
                className="surface-lux flex flex-col gap-5 rounded-2xl p-5 sm:flex-row sm:items-center"
              >
                <img
                  src={item.img}
                  alt={item.nome}
                  loading="lazy"
                  width={1024}
                  height={1024}
                  className="h-40 w-full rounded-xl object-cover sm:size-40"
                />
                <div className="flex-1">
                  <p className="text-xs uppercase tracking-[0.3em] text-gold">{item.chamada}</p>
                  <h3 className="mt-1 text-2xl">{item.nome}</h3>
                  <p className="mt-2 text-sm text-muted-foreground">{item.descricao}</p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {item.tags.map((t) => (
                      <span
                        key={t}
                        className="rounded-full bg-secondary px-3 py-1 text-[11px] uppercase tracking-wider text-muted-foreground"
                      >
                        {t}
                      </span>
                    ))}
                  </div>
                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-2xl font-bold text-gradient-gold">{brl(item.preco)}</span>
                    <button
                      onClick={() => add(item.id)}
                      className="rounded-full bg-primary px-6 py-3 text-xs font-bold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-[1.04]"
                    >
                      Adicionar à comanda
                    </button>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="lg:sticky lg:top-24 lg:self-start">
            <Conta itens={ITENS} linhas={linhas} add={add} remove={remove} />
          </div>
        </div>
      </section>

      <section className="border-y border-border bg-card/40">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 sm:grid-cols-3">
          {[
            ["Servido em 48h", "Preparo e envio expresso para todo o Brasil."],
            ["Algodão penteado", "Malha macia, costura invisível e cano que não cai."],
            ["Troca sem stress", "7 dias para trocar o tamanho, por nossa conta."],
          ].map(([t, d]) => (
            <div key={t}>
              <h3 className="text-2xl">{t}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="mx-auto max-w-6xl px-5 py-12 text-center text-xs text-muted-foreground">
        © {new Date().getFullYear()} Meia Porção · Meias de sushi e lanche feitas com fome de estilo.
      </footer>
    </main>
  );
}
