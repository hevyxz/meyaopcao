import { useMemo, useState } from "react";

const WHATSAPP_NUMERO = "5511961252181";

export type Item = {
  id: string;
  nome: string;
  chamada: string;
  descricao: string;
  preco: number;
  img: string;
  tags: string[];
};

export const brl = (v: number) =>
  v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export function useComanda() {
  const [linhas, setLinhas] = useState<Record<string, number>>({});

  const add = (id: string) => setLinhas((l) => ({ ...l, [id]: (l[id] ?? 0) + 1 }));
  const remove = (id: string) =>
    setLinhas((l) => {
      const q = (l[id] ?? 0) - 1;
      const next = { ...l };
      if (q <= 0) delete next[id];
      else next[id] = q;
      return next;
    });

  return { linhas, add, remove, limpar: () => setLinhas({}) };
}

export function Conta({
  itens,
  linhas,
  add,
  remove,
}: {
  itens: Item[];
  linhas: Record<string, number>;
  add: (id: string) => void;
  remove: (id: string) => void;
}) {
  const [endereco, setEndereco] = useState("");
  const selecionados = itens.filter((i) => linhas[i.id]);
  const subtotal = useMemo(
    () => selecionados.reduce((s, i) => s + i.preco * linhas[i.id], 0),
    [selecionados, linhas],
  );
  const pares = selecionados.reduce((s, i) => s + linhas[i.id], 0);
  const servico = subtotal * 0.1;

  const mensagem = [
    "PRODUTO FINALIZADO AO CARDÁPIO QUENTINHO E SABOROSO.",
    "",
    `QUANTIDADE: ${pares}`,
    `NOME DO PRODUTOS: ${selecionados.map((i) => `${linhas[i.id]}x ${i.nome}`).join(", ")}`,
    `VALOR TOTAL: ${brl(subtotal)}`,
    `ENDEREÇO DE ENTREGA: ${endereco.trim()}`,
  ].join("\n");
  const podeEnviar = selecionados.length > 0 && endereco.trim().length > 3;

  return (
    <div className="surface-lux rounded-2xl p-6 sm:p-8">
      <div className="flex items-baseline justify-between border-b border-dashed border-border pb-4">
        <h3 className="text-3xl">A conta, por favor</h3>
        <span className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Mesa {String(pares || 1).padStart(2, "0")}
        </span>
      </div>

      {selecionados.length === 0 ? (
        <p className="py-10 text-center text-sm text-muted-foreground">
          Sua comanda está vazia. Escolha um par no cardápio ao lado.
        </p>
      ) : (
        <ul className="divide-y divide-dashed divide-border">
          {selecionados.map((i) => (
            <li key={i.id} className="flex items-center gap-4 py-4">
              <div className="flex-1">
                <p className="font-semibold">{i.nome}</p>
                <p className="text-xs text-muted-foreground">
                  {linhas[i.id]} × {brl(i.preco)}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => remove(i.id)}
                  aria-label={`Remover ${i.nome}`}
                  className="size-8 rounded-full border border-border text-lg leading-none transition-colors hover:bg-secondary"
                >
                  −
                </button>
                <span className="w-5 text-center tabular-nums">{linhas[i.id]}</span>
                <button
                  onClick={() => add(i.id)}
                  aria-label={`Adicionar ${i.nome}`}
                  className="size-8 rounded-full border border-border text-lg leading-none transition-colors hover:bg-secondary"
                >
                  +
                </button>
              </div>
              <span className="w-24 text-right font-semibold tabular-nums">
                {brl(i.preco * linhas[i.id])}
              </span>
            </li>
          ))}
        </ul>
      )}

      <dl className="mt-4 space-y-2 border-t border-dashed border-border pt-4 text-sm">
        <div className="flex justify-between">
          <dt className="text-muted-foreground">Subtotal</dt>
          <dd className="tabular-nums">{brl(subtotal)}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-muted-foreground">Taxa de serviço (10%) — cortesia</dt>
          <dd className="tabular-nums text-muted-foreground line-through">{brl(servico)}</dd>
        </div>
        <div className="flex justify-between">
          <dt className="text-muted-foreground">Entrega</dt>
          <dd className="text-muted-foreground">
            {subtotal === 0 ? "—" : "A combinar no WhatsApp"}
          </dd>
        </div>
        <div className="flex items-baseline justify-between border-t border-border pt-3">
          <dt className="text-2xl" style={{ fontFamily: "var(--font-display)" }}>
            Total
          </dt>
          <dd className="text-2xl font-bold tabular-nums text-gradient-gold">
            {brl(subtotal)}
          </dd>
        </div>
      </dl>

      <div className="mt-6">
        <label
          htmlFor="endereco"
          className="mb-2 block text-xs uppercase tracking-[0.25em] text-gold"
        >
          Endereço de entrega
        </label>
        <textarea
          id="endereco"
          value={endereco}
          onChange={(e) => setEndereco(e.target.value)}
          rows={3}
          placeholder="Rua, número, complemento, bairro, cidade e CEP"
          className="w-full rounded-xl border border-border bg-secondary/40 px-4 py-3 text-sm outline-none transition-colors placeholder:text-muted-foreground focus:border-gold"
        />
      </div>

      {podeEnviar ? (
        <a
          href={`https://wa.me/${WHATSAPP_NUMERO}?text=${encodeURIComponent(mensagem)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-4 flex w-full items-center justify-center rounded-full bg-primary px-6 py-4 text-sm font-bold uppercase tracking-[0.2em] text-primary-foreground transition-transform hover:scale-[1.02]"
          style={{ boxShadow: "var(--shadow-lux)" }}
        >
          Finalizar pedido no WhatsApp
        </a>
      ) : (
        <button
          type="button"
          disabled
          className="mt-4 flex w-full cursor-not-allowed items-center justify-center rounded-full bg-secondary px-6 py-4 text-sm font-bold uppercase tracking-[0.2em] text-muted-foreground"
        >
          Finalizar pedido no WhatsApp
        </button>
      )}
      {!podeEnviar && (
        <p className="mt-2 text-center text-xs text-muted-foreground">
          Escolha um item e informe o endereço para enviar o pedido.
        </p>
      )}
      <p className="mt-3 text-center text-xs text-muted-foreground">
        Pix, cartão ou vale-refeição (sim, dá pra pagar com VR 🍔)
      </p>
    </div>
  );
}